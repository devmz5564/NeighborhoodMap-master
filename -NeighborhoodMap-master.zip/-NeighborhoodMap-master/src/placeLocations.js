
export const locations =

    [
        {
            title: '  Citadel of Qaitbay (قلعة قايت باي)  ',
            location: { lat: 31.214011, lng: 29.885638 } 
        },

        { 
            title: 'alexandria bibliotheca     (مكتبة الاسكندرية) ',
            location: { lat: 31.208870, lng: 29.909201 }
         },

        { 
            title: 'Royal Jewelry Museum (متحف المجوهرات) ', 
            location: { lat: 31.240700, lng: 29.963300 } 
        },
        { 
            title: 'Alexandria National Museum (متحف الإسكندرية القومي)', 
            location: { lat: 31.200955, lng: 29.913258 } 
        },
        { 
            title: 'Catacombs Koum El Shoukkafa (مقبرة كوم الشقافة)', 
            location: { lat: 31.178959, lng: 29.893077 } 
        },
        { 
            title: 'Pompey Pillar ِAlexandria', 
            location: { lat: 31.182500, lng: 29.896400 } 
        }
     
       
    ]